#include "LinkedList.h"

int main(void) {
    listTest();
    return 0;
}